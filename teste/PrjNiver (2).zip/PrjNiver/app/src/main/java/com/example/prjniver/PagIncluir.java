package com.example.prjniver;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class PagIncluir extends AppCompatActivity {
    Button btnInc, btnVoltar;
    EditText txtNome, txtData;
    BancoDados bd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_pag_incluir);
        btnVoltar = findViewById(R.id.btnVoltar);
        btnInc = findViewById(R.id.btnInc);
        txtNome = findViewById(R.id.txtNome);
        txtData = findViewById(R.id.txtData);
        bd = new BancoDados();
        bd.criar_banco_tabela(this);

        btnVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent next = new Intent(getBaseContext(),PagPessoas.class);
                startActivity(next);

            }
        });

        btnInc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nome = txtNome.getText().toString().trim();
                String data = txtData.getText().toString().trim();

                if (!nome.isEmpty() && !data.isEmpty()) {
                    boolean sucesso = bd.inserirAniversario(PagIncluir.this, nome, data);

                    if (sucesso) {
                        Toast.makeText(PagIncluir.this, "Aniversário incluído com sucesso!", Toast.LENGTH_SHORT).show();
                        txtNome.setText("");
                        txtData.setText("");
                    } else {
                        Toast.makeText(PagIncluir.this, "Erro ao incluir!", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}