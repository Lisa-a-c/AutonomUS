package com.example.prjniver;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import java.util.ArrayList;
import java.util.List;

public class BancoDados {
    private SQLiteDatabase banco = null;
    private final String NOME_DO_BANCO = "banco.db";
    private final String NOME_TABELA = "aniversarios";
    private Cursor cursor;

    public boolean criar_banco_tabela(Context cx) {
        try {
            banco = cx.openOrCreateDatabase(NOME_DO_BANCO, Context.MODE_PRIVATE, null);
            String sql = "CREATE TABLE IF NOT EXISTS " + NOME_TABELA + " (id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT, data_nasc TEXT);";
            banco.execSQL(sql);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public boolean inserirAniversario(Context cx, String nome, String data) {
        try {
            banco = cx.openOrCreateDatabase(NOME_DO_BANCO, Context.MODE_PRIVATE, null);
            ContentValues valores = new ContentValues();
            valores.put("nome", nome);
            valores.put("data_nasc", data);
            long resultado = banco.insert(NOME_TABELA, null, valores);
            return resultado != -1; // Retorna true se inserção for bem-sucedida
        } catch (Exception e) {
            return false;
        }
    }
    public List<String> consultar(Context cx, String query) {
        try {
            banco = cx.openOrCreateDatabase(NOME_DO_BANCO, Context.MODE_PRIVATE, null);
            cursor = banco.rawQuery(query, null);
            List<String> lista = new ArrayList<>();

            if (cursor.moveToFirst()) {
                do {
                    lista.add(cursor.getString(0) + " - " + cursor.getString(1));
                } while (cursor.moveToNext());
            }
            cursor.close();
            return lista;
        } catch (Exception e) {
            return null;
        }
    }


    public int contarRegistros(Context cx) {
        try {
            banco = cx.openOrCreateDatabase(NOME_DO_BANCO, Context.MODE_PRIVATE, null);
            cursor = banco.rawQuery("SELECT * FROM " + NOME_TABELA, null);
            return cursor.getCount();
        } catch (Exception e) {
            return 0;
        }
    }
}
