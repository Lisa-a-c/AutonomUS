package com.example.prjniver;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    Button btnPessoas;
    ListView lstAni;
    BancoDados Banco;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        btnPessoas = findViewById(R.id.btnPessoas);
        lstAni = findViewById(R.id.lstAni);
        Banco = new BancoDados();
        List<String> lista = Banco.consultar( MainActivity.this, "SELECT nome, data_nasc FROM aniversarios"); //arrumar isso aqui depois nn estou conseguindo fazer a query que precisa para pegar os 15 dias mas o resto esta feito 
        if (lista != null && !lista.isEmpty()) {
            lstAni.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, lista));
        } else {
            Toast.makeText(this, "Nenhum aniversário cadastrado!", Toast.LENGTH_SHORT).show();
        }

        btnPessoas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent next = new Intent(getBaseContext(),PagPessoas.class);
                startActivity(next);
            }
        });

    }
}